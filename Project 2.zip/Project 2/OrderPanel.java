//SITI AZEEZA BINTI MOHAMMAD (BI19110030)
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class OrderPanel extends JPanel {
    private JLabel foodList;
    private JList Food;
    private JLabel quantityFood;
    private JTextField quantityFoodText;
    private JLabel drinkList;
    private JList jcomp6;
    private JLabel quantityDrink;
    private JTextField jcomp8;
    private JLabel totalPrice;
    private JTextField jcomp10;

    public OrderPanel() {
        //construct preComponents
        String[] FoodItems = {"Burger", "Speghetti", "Fried Chicken"};
        String[] jcomp6Items = {"Cola", "Pepsi", "Sprite", "Tea", "Coffee"};

        //construct components
        foodList = new JLabel ("Food:");
        Food = new JList (FoodItems);
        quantityFood = new JLabel ("Quantity:");
        quantityFoodText = new JTextField (2);
        drinkList = new JLabel ("Drink:");
        jcomp6 = new JList (jcomp6Items);
        quantityDrink = new JLabel ("Quantity:");
        jcomp8 = new JTextField (2);
        totalPrice = new JLabel ("Total Price");
        jcomp10 = new JTextField (5);

        //adjust size and set layout
        setPreferredSize (new Dimension (413, 519));
        setLayout (null);

        //add components
        add (foodList);
        add (Food);
        add (quantityFood);
        add (quantityFoodText);
        add (drinkList);
        add (jcomp6);
        add (quantityDrink);
        add (jcomp8);
        add (totalPrice);
        add (jcomp10);

        //set component bounds (only needed by Absolute Positioning)
        foodList.setBounds (90, 40, 100, 25);
        Food.setBounds (90, 65, 100, 75);
        quantityFood.setBounds (210, 40, 100, 25);
        quantityFoodText.setBounds (205, 65, 67, 25);
        drinkList.setBounds (90, 155, 100, 25);
        jcomp6.setBounds (90, 180, 100, 75);
        quantityDrink.setBounds (210, 155, 100, 25);
        jcomp8.setBounds (205, 180, 67, 25);
        totalPrice.setBounds (90, 280, 70, 25);
        jcomp10.setBounds (155, 280, 100, 25);
    }


    public static void main (String[] args) {
        JFrame frame = new JFrame ("Order");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add (new OrderPanel());
        frame.pack();
        frame.setVisible (true);
    }
}
