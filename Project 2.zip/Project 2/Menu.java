//SITI AZEEZA BINTI MOHAMMAD (BI19110030)

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Menu implements ActionListener {

   JTextField jtfPlaintext;
   JLabel jlab, jlab1, jlab2, jlab3, jlab4, jlab5, jlab6, jlab7, jlab8;
   
   Menu() {
   JFrame jfrm = new JFrame("Customer and Menu Details");
   jfrm.setLayout (new FlowLayout());
   jfrm.setSize(200, 300);
   jfrm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   
   jlab = new JLabel("List Of Menu");
   jfrm.add(jlab);
   jlab1 = new JLabel("Burger RM2.50"); 
   jfrm.add(jlab1);
   jlab2 = new JLabel("Speghetti RM5.00");
   jfrm.add(jlab2);
   jlab3 = new JLabel ("Fried Chicken  RM3.00");
   jfrm.add(jlab3);
   jlab4 = new JLabel("Cola RM2.00");
   jfrm.add(jlab4);
   jlab5 = new JLabel("Pepsi RM2.00");
   jfrm.add(jlab5);
   jlab6 = new JLabel("Sprite RM2.00");
   jfrm.add(jlab6);
   jlab7 = new JLabel("Tea RM1.80");
   jfrm.add(jlab7);
   jlab8 = new JLabel("Coffee RM1.80   ");
   jfrm.add(jlab8);
   
   JLabel jlabPlaintext = new JLabel("Customer Name:  ");
   
   jtfPlaintext = new JTextField(20);
  
   jtfPlaintext.addActionListener(this);
  
   JButton jbtnFirst = new JButton("Enter");
   
   jbtnFirst.addActionListener(this);
   
   jfrm.add(jlabPlaintext);
   jfrm.add(jtfPlaintext);
   jfrm.add(jbtnFirst);
  
   jfrm.setVisible(true);
   
 
   }
   
   public void actionPerformed(ActionEvent ae) {
   
      if(ae.getActionCommand().equals("Enter"))
         jlab.setText("Your name already recorded.");
      else 
         jlab.setText("Enter your name");
      }
      
   public static void main(String[] args) {
      SwingUtilities.invokeLater(new Runnable() {
         public void run() {
            new Menu();
            }
          });
      }
   }


   