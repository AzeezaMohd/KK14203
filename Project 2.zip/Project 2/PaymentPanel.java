//SITI AZEEZA BINTI MOHAMMAD (BI19110030)
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class PaymentPanel extends JPanel {
    private JLabel paymentMet;
    private JComboBox paymentList;
    private JLabel totalPayment;
    private JTextField jcomp4;

    public PaymentPanel() {
        //construct preComponents
        String[] paymentListItems = {"Cash", "Credit Card", "Debit Card"};

        //construct components
        paymentMet = new JLabel ("Payment Method");
        paymentList = new JComboBox (paymentListItems);
        totalPayment = new JLabel ("Total (RM)");
        jcomp4 = new JTextField (5);

        //adjust size and set layout
        setPreferredSize (new Dimension (300, 150));
        setLayout (null);

        //add components
        add (paymentMet);
        add (paymentList);
        add (totalPayment);
        add (jcomp4);

        //set component bounds (only needed by Absolute Positioning)
        paymentMet.setBounds (35, 35, 100, 25);
        paymentList.setBounds (155, 35, 100, 25);
        totalPayment.setBounds (75, 75, 100, 25);
        jcomp4.setBounds (155, 80, 100, 25);
    }


    public static void main (String[] args) {
        JFrame frame = new JFrame ("Payment");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add (new PaymentPanel());
        frame.pack();
        frame.setVisible (true);
    }
}

