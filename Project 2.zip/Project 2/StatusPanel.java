//SITI AZEEZA BINTI MOHAMMAD (BI19110030)
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class StatusPanel extends JPanel {
    private JRadioButton status1;
    private JRadioButton status2;
    private JRadioButton status3;
    private JSlider bodyTempScale;
    private JLabel bodyTemp;
    private JLabel tableNum;
    private JTextField tableNumText;
    private JLabel phoneNum;
    private JTextField phoneNumText;
    private JLabel address;
    private JTextArea addressText;
    private JLabel turnNum;
    private JTextField turnNumText;

    public StatusPanel() {
        //construct components
        status1 = new JRadioButton ("Dine In");
        status2 = new JRadioButton ("Delivery");
        status3 = new JRadioButton ("Take Away");
        bodyTempScale = new JSlider (30, 40);
        bodyTemp = new JLabel ("Body Temperature");
        tableNum = new JLabel ("Table Number");
        tableNumText = new JTextField (4);
        phoneNum = new JLabel ("Phone Number");
        phoneNumText = new JTextField (10);
        address = new JLabel ("Address");
        addressText = new JTextArea (5, 15);
        turnNum = new JLabel ("Turn Number");
        turnNumText = new JTextField (3);

        //set components properties
        status1.setToolTipText ("1");
        status2.setToolTipText ("2");
        status3.setToolTipText ("3");
        bodyTempScale.setOrientation (JSlider.HORIZONTAL);
        bodyTempScale.setMinorTickSpacing (1);
        bodyTempScale.setMajorTickSpacing (35);
        bodyTempScale.setPaintTicks (true);
        bodyTempScale.setPaintLabels (true);

        //adjust size and set layout
        setPreferredSize (new Dimension (624, 335));
        setLayout (null);

        //add components
        add (status1);
        add (status2);
        add (status3);
        add (bodyTempScale);
        add (bodyTemp);
        add (tableNum);
        add (tableNumText);
        add (phoneNum);
        add (phoneNumText);
        add (address);
        add (addressText);
        add (turnNum);
        add (turnNumText);

        //set component bounds (only needed by Absolute Positioning)
        status1.setBounds (100, 10, 100, 25);
        status2.setBounds (95, 100, 100, 25);
        status3.setBounds (95, 210, 100, 25);
        bodyTempScale.setBounds (220, 35, 100, 50);
        bodyTemp.setBounds (210, 10, 114, 25);
        tableNum.setBounds (360, 10, 100, 25);
        tableNumText.setBounds (360, 35, 80, 25);
        phoneNum.setBounds (210, 100, 100, 25);
        phoneNumText.setBounds (210, 125, 115, 25);
        address.setBounds (355, 100, 100, 25);
        addressText.setBounds (345, 125, 115, 75);
        turnNum.setBounds (205, 210, 100, 25);
        turnNumText.setBounds (205, 235, 70, 25);
    }


    public static void main (String[] args) {
        JFrame frame = new JFrame ("Status");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add (new StatusPanel());
        frame.pack();
        frame.setVisible (true);
    }
}

